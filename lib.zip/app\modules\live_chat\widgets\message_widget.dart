import 'package:intl/intl.dart';
import 'package:mh/app/common/controller/app_controller.dart';
import 'package:mh/app/common/utils/exports.dart';
import 'package:mh/app/modules/live_chat/models/message_response_model.dart';

class MessageWidget extends StatelessWidget {
  final MessageModel messageModel;
  final int index;
  const MessageWidget({super.key, required this.messageModel, required this.index});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: messageModel.senderId == Get.find<AppController>().user.value.userId
          ? MainAxisAlignment.end
          : MainAxisAlignment.start,
      children: [
        Flexible(
          flex: 10,
          child: Container(
              margin: const EdgeInsets.only(
                  bottom: 10.0),
              padding:  EdgeInsets.symmetric(horizontal: 10.0.sp, vertical: 5.0.sp),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12.0),
                  color: messageModel.senderId == Get.find<AppController>().user.value.userId
                      ? MyColors.c_C6A34F
                      : Colors.blueGrey.shade300),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Flexible(
                    flex: 3,
                      child: Text('${messageModel.text}', style: Get.width>600?MyColors.white.medium12:MyColors.white.medium15)),
                  const SizedBox(width: 10),
                  Flexible(
                    flex: 1,
                      child: Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text(
                        DateFormat.jm().format(messageModel.dateTime ?? DateTime.now()),
                        style: Get.width>600?Colors.grey.shade100.medium9:Colors.grey.shade100.medium10),
                  )),
                /*  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                          DateFormat.jm().format(messageModel.dateTime ?? DateTime.now()),
                          style: Colors.grey.shade100.medium10),
                      Visibility(
                          visible:
                          messageModel.senderDetails?.senderId == Get.find<AppController>().user.value.userId,
                          child: const Icon(Icons.check, color: Colors.white, size: 12))
                    ],
                  )*/
                ],
              )),
        ),
        const Flexible(
          flex: 1,
            child: Wrap())
      ],
    );
  }
}
/*
Column(
mainAxisAlignment: MainAxisAlignment.end,
children: [
const SizedBox(height: 15),
Row(
children: [
Text(
DateFormat.jm().format(messageModel.dateTime ?? DateTime.now()),
style: Colors.grey.shade100.medium10),
Visibility(
visible:
messageModel.senderDetails?.senderId == Get.find<AppController>().user.value.userId,
child: const Icon(Icons.check, color: Colors.white, size: 12))
],
)
],
)*/
