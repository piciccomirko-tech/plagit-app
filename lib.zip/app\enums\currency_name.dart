enum CurrencyName { pound, dirHam }
