enum AppThemes {
  light,
  dark,
}
