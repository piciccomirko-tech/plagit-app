enum SelectedPaymentMethod {
  card,
  bank,
}
