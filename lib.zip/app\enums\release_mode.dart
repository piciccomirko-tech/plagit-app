enum ReleaseMode {
  debug,
  release,
}
